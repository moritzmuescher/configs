return {
  "nvim-neo-tree/neo-tree.nvim",
  branch = "v3.x",
  dependencies = {
    "nvim-lua/plenary.nvim",
    "nvim-tree/nvim-web-devicons",
    "MunifTanjim/nui.nvim",
  },
  opts = {
    filesystem = {
      filtered_items = {
        visible = true, -- Show hidden files by default (like Netrw)
        hide_dotfiles = false,
      },
      follow_current_file = {
        enabled = true, -- Sync with current buffer
      },
      hijack_netrw_behavior = "open_default", -- Replace Netrw when :Ex is used
    },
    window = {
      position = "left",
      width = 30,
    },
    event_handlers = {
      {
        event = "file_opened",
        handler = function()
          -- Auto-close after opening a file (optional, Netrw-like)
          require("neo-tree.command").execute({ action = "close" })
        end,
      },
    },
    mappings = {
      ["<CR>"] = function(state)
        local node = state.tree:get_node()
        if node.type == "directory" then
          if node.name == ".." then
            -- Go up to parent directory when on ../
            require("neo-tree.sources.filesystem").navigate_up(state)
          else
            -- Enter the directory
            require("neo-tree.sources.filesystem").navigate(state, node:get_id())
          end
        elseif node.type == "file" then
          -- Open the file
          require("neo-tree.sources.filesystem.commands").open(state)
        end
      end,
    },
  },
}
