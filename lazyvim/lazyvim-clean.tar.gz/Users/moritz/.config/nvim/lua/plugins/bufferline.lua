return {
  "akinsho/bufferline.nvim",
  enabled = false,
}
