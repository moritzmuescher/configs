return {
  "folke/noice.nvim",
  enabled = false,
}
