return {
  "lervag/vimtex",
  lazy = false, -- Load immediately for LaTeX files
  init = function()
    -- Vimtex configuration
    vim.g.vimtex_view_method = "zathura" -- Default PDF viewer (adjust based on your system)
    vim.g.vimtex_compiler_method = "latexmk" -- Use latexmk for compilation
    vim.g.tex_flavor = "latex" -- Ensure LaTeX is the default flavor
  end,
  ft = { "tex" }, -- Load only for .tex files
}
