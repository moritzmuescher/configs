vim.g.netrw_banner = 0 -- Hide the banner
vim.g.netrw_liststyle = 3
